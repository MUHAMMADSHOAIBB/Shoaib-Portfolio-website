from flask import Flask,render_template,request,redirect
import mysql.connector
app = Flask(__name__)
@app.route("/")
def home():
    return render_template("index.html")
@app.route("/result",methods=["GET","Post"])
def result():
    db = mysql.connector.connect(host='localhost', user='root', password='', database="shoaib")
    mycursor = db.cursor()
    if request.method=="POST":
        #fetch from data
        user_details =request.form
        name=user_details['name']
        email = user_details['email']
        message = user_details['message']
        mycursor.execute("INSERT INTO message(name,email,message) VALUES(%s, %s, %s)",(name,email,message))
        db.commit()
        mycursor.close()
        return render_template ('result.html')





if __name__ == "__main__":
    app.run(debug=True)
